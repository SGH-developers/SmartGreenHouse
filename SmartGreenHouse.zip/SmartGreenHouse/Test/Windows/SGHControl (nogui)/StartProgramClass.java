import java.io.*;
import java.awt.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class StartProgramClass {
    static String InStr;
    static String Host;
    static String tcpMassage = "";

    public static void main(String[] args) throws Exception {
        BufferedReader InReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("   _____  _____ _    _ ");
        System.out.println("  / ____|/ ____| |  | |");
        System.out.println(" | (___ | |  __| |__| |");
        System.out.println("  \\___ \\| | |_ |  __  |");
        System.out.println("  ____) | |__| | |  | |");
        System.out.println(" |_____/ \\_____|_|  |_|");
        System.out.println("                       ");

        System.out.println("Запущен пульт управления комплексом SmartGreenHouse");
        System.out.println("Введите [y/n] для продолжения или отмены");

        boolean r = true;
        while(r ==true) {
            System.out.print(">>> ");
            InStr = InReader.readLine();

            if (InStr.equals("y") || InStr.equals("Y") || InStr.equals("д") || InStr.equals("Д")) {
                while(r == true){
                    System.out.println("Введите ip адрес теплицы");
                    System.out.print(">>> ");
                    String InStr = InReader.readLine();
                    if(InStr.equals("exit")){
                        return;
                    }
                    if(InStr.equals("")){
                        continue;
                    }
                    System.out.println("Подключение...");
                    Host = InStr;
                    try {
                        Socket clientSocket = new Socket (Host,80);
                        InputStream is = clientSocket.getInputStream();
                        BufferedReader TcpIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                        PrintWriter TcpOut = new PrintWriter(clientSocket.getOutputStream(), true);
                        TcpOut.println("connect?");                  
                        tcpMassage = TcpIn.readLine();
                        if(tcpMassage.equals("connect!")){
                        	System.out.println(tcpMassage+" Ура работает");
                        }
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        System.out.println("Ошибка, устройство не найдено");
                        System.out.println("Проверте правильность ввода и подключение к интернету");
                        System.out.println("");
                    }
                }
            }
            if (InStr.equals("v") || InStr.equals("V") || InStr.equals("version") || InStr.equals("в")) {
                System.out.println("SmartGreenHouse version 0.1 beta by NX-Man");
            } else {
                return;
            }
        }
    }
}

